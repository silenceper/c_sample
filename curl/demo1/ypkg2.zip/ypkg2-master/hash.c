#ifndef HASH_H
#define HASH_H

char *sha1( char *file )
{
}


#endif /* !HASH_H */
