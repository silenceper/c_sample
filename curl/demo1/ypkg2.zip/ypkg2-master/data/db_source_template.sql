REPLACE INTO source( id, name, repo, last_update, last_check, has_new, checksum ) VALUES( NULL, 'xxx', 'yyy', 0, 0, 1, 'a' );
